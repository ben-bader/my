#!/usr/bin/env python
# (coding: utf-8)
from distutils.core import setup
setup(name='script',
	version='1.7.2',
	author='Iain Lamb',
	author_email='x+python@lamb.cc',
	description='Help for writing shell scripts in Python',
	url='http://lamb.cc/script',
	license='Copyright (c) 2010 by Iain Lamb. Licensed to PSF under a Contributor Agreement. See http://www.python.org/3.1/license for details.',
	py_modules=['script'],
	classifiers=['Development Status :: 5 - Production/Stable', 'Environment :: Console', 'Intended Audience :: Developers', 'Intended Audience :: System Administrators', 'License :: OSI Approved :: Python Software Foundation License', 'Natural Language :: English', 'Operating System :: OS Independent', 'Programming Language :: Python :: 3', 'Topic :: System :: Shells', 'Topic :: Terminals', 'Topic :: Utilities'],
	long_description="""Use with Python 3.


This module is mostly for folks who need to write a python script
that will be run from the command line. You know, something that can
parse command line arguments and run other external programs via the
shell. The kind of script you can call with --help. Something that
perhaps reads, copies, deletes, or otherwise manipulates files by
their pathname.

If any of these apply, perhaps this module is for you!

A simple ``import script`` statement can provide your code with
convenient command line parsing, à la carte ``--help`` documentation,
useful path operations, shell command invocation with optional pipe
redirection, and early run-time termination with exit status
control. Read on for more. Cheers!
""")
	